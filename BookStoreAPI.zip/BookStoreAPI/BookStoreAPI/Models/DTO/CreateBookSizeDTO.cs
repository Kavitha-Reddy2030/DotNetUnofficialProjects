﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookStoreAPI.Models.DTO
{
    public class CreateBookSizeDTO
    {
        public string Size { get; set; }
    }
}
